import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class Talker(Node):
    def __init__(self):
        super().__init__('dora_talker')
        self.pub = self.create_publisher(Twist, '/dora/cmd_vel', 10)
        self.timer = self.create_timer(0.5, self.on_timer)
        self.cnt = 0

    def on_timer(self):
        msg = Twist()
        msg.linear.x = 0.1 * (self.cnt % 10)
        msg.angular.z = 0.01 * (self.cnt % 20)
        self.pub.publish(msg)
        self.get_logger().info(f'Published cmd_vel: linear.x={msg.linear.x:.2f}')
        self.cnt += 1

def main():
    rclpy.init()
    node = Talker()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    rclpy.shutdown()
