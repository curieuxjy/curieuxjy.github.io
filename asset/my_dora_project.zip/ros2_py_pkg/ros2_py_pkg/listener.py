import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class Listener(Node):
    def __init__(self):
        super().__init__('dora_listener')
        self.sub = self.create_subscription(Twist, '/dora/cmd_vel', self.cb, 10)

    def cb(self, msg):
        self.get_logger().info(f'Recv cmd_vel: linear.x={msg.linear.x:.3f}, angular.z={msg.angular.z:.3f}')

def main():
    rclpy.init()
    node = Listener()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    rclpy.shutdown()
