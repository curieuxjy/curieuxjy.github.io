// rust-heartbeat-node/src/main.rs
// 간단한 Dora 노드 예제: "heartbeat"라는 output data id로 u64 카운터를 주기적으로 전송합니다.
// 이 노드는 dora 런타임이 spawn 하도록 dataflow.yml에서 정의해 사용합니다.
//
// 주의: DoraNode::init_from_env()는 dora가 환경변수를 설정해 spawn했을 때 정상 동작합니다.
// 독립 실행(데몬 없이) 테스트 시에는 문서의 개발용 초기화 헬퍼를 참고하세요.

use anyhow::Result;
use std::time::Duration;
use tokio::time::sleep;
use futures::StreamExt;

use dora_node_api::{DoraNode, MetadataParameters};
use dora_core::config::DataId;

#[tokio::main]
async fn main() -> Result<()> {
    // dora가 노드를 spawn할 때 설정해주는 환경변수로부터 초기화합니다.
    // (보통 dataflow.yml 통해 dora가 스폰하므로 로컬에서 단독 실행 시 실패할 수 있음)
    let (mut node, mut events) = DoraNode::init_from_env()
        .expect("failed to init Dora node from env");

    // dataflow.yml의 outputs에 정의한 id와 동일하게 설정하세요.
    let output_id = DataId::from("heartbeat".to_owned());

    let mut counter: u64 = 0;

    loop {
        // 보낼 데이터: u64 -> 8바이트
        let bytes = counter.to_le_bytes();

        // zero-copy 방식: 제공된 버퍼에 직접 채워 전송
        node.send_output_raw(
            output_id.clone(),
            MetadataParameters::default(),
            bytes.len(),
            |out_buf| {
                out_buf.copy_from_slice(&bytes);
            }
        )?;

        println!("Sent heartbeat {}", counter);
        counter += 1;

        // 이벤트(입력/제어 등)를 비동기적으로 처리 (여기서는 drain)
        while let Ok(Some(evt)) = tokio::time::timeout(Duration::from_millis(0), events.next()).await {
            // 실제 노드에서는 Event::Input 등의 처리 로직을 넣으세요.
            println!("Dora event: {:?}", evt);
        }

        sleep(Duration::from_millis(500)).await;
    }
}
